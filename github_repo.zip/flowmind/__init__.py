"""FlowMind — local AI gateway with provider routing and automatic failover."""

__version__ = "0.2.0"
