"""FlowMind Router — resolves models and delegates to the failover engine."""

from __future__ import annotations

from typing import Any

import flowmind.config as cfg
from flowmind.failover import call_with_failover
from flowmind.providers import gemini, openrouter, nvidia

_PROVIDER_MODULES = {
    "gemini":     gemini,
    "openrouter": openrouter,
    "nvidia":     nvidia,
}


async def route(model: str, messages: list[dict], temperature: float, max_tokens: int) -> dict[str, Any]:
    """
    Build the outbound payload and call the failover engine.

    Model resolution uses the cached best_model from `flowmind init` so users
    never need to specify model names.
    """
    priority = cfg.get_provider_priority()

    # Pick the first configured provider for model resolution
    resolving_provider = priority[0] if priority else "gemini"
    mod = _PROVIDER_MODULES.get(resolving_provider, gemini)

    # Use cached best_model from init; fall back to provider default
    best_model = cfg.get_best_model(resolving_provider) or mod.DEFAULT_MODEL
    resolved_model = mod.resolve(model, best_model=best_model)

    payload: dict[str, Any] = {
        "model":       resolved_model,
        "messages":    messages,
        "temperature": temperature,
        "max_tokens":  max_tokens,
    }

    return await call_with_failover(payload)
